﻿using LabWork9.Context;
using LabWork9.Models;
using LabWork9.Services;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
optionsBuilder.UseSqlServer("Data Source=mssql;Initial Catalog=ispp3109;User ID=ispp3109;Password=3109;Trust Server Certificate=True");
using var context = new AppDbContext();

var visitorService = new VisitorService(context);
var visitors = await visitorService.GetVisitorsAsync();
foreach (var visitor in visitors)
    Console.WriteLine($"{visitor.VisitorId}, {visitor.Phone}," +
        $" {visitor.Name}, {visitor.Birthday}, {visitor.Email}");

var ticketService = new TicketService(context);
var tickets = await ticketService.GetTicketsAsync();
foreach (var ticket in tickets)
    Console.WriteLine($"{ticket.TicketId}, {ticket.SessionId}," +
        $" {ticket.VisitorId}, {ticket.Row}, {ticket.Seat}");

var newVisitor = new Visitor()
{
    Phone = "9358881234",
    Name = "Никита",
    Birthday = DateTime.Today,
    Email = "nikitka@gmail.com"
};
await visitorService.AddVisitorAsync(newVisitor);

var newTicket = new Ticket()
{
    SessionId = 1,
    VisitorId = 5,
    Row = 5,
    Seat = 12
};
await ticketService.AddTicketAsync(newTicket);

var updateVisitor = context.Visitors.Find(5);
updateVisitor.Name = "Полина";
await visitorService.UpdateVisitorAsync(updateVisitor);

var updateTicket = new Ticket()
{
    TicketId = 6,
    Row = 7,
    Seat = 10
};
await ticketService.UpdateTicketAsync(updateTicket);
