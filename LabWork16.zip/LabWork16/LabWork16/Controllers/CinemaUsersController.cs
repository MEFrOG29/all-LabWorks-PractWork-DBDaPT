﻿using LabWork16.Contexts;
using LabWork16.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using NuGet.Protocol.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LabWork16.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CinemaUsersController : ControllerBase
    {
        private readonly MarketContext _context;

        public CinemaUsersController(MarketContext context)
        {
            _context = context;
        }

        // GET: api/CinemaUsers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CinemaUser>>> GetCinemaUsers()
        {
            return await _context.CinemaUsers.ToListAsync();
        }

        // GET: api/CinemaUsers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CinemaUser>> GetCinemaUser(int id)
        {
            var cinemaUser = await _context.CinemaUsers.FindAsync(id);

            if (cinemaUser == null)
            {
                return NotFound();
            }

            return cinemaUser;
        }

        // PUT: api/CinemaUsers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCinemaUser(int id, CinemaUser cinemaUser)
        {
            if (id != cinemaUser.UserId)
            {
                return BadRequest();
            }

            _context.Entry(cinemaUser).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CinemaUserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CinemaUsers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("/auth/register")]
        public async Task<bool> RegisterCinemaUser(LoginRequest loginRequest)
        {
            if (_context.CinemaUsers.FirstOrDefault(u => u.Login == loginRequest.Login) is not null)
                return false;
            var user = new CinemaUser()
            {
                Login = loginRequest.Login,
                PasswordHash = BCrypt.Net.BCrypt.EnhancedHashPassword(loginRequest.Password),
                RoleId = 3
            };
            _context.CinemaUsers.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }

        [HttpPost("/auth/login")]
        public async Task<TokenResponce> LoginCinemaUser(LoginRequest loginRequest)
        {
            var user = _context.CinemaUsers.FirstOrDefault(u => u.Login == loginRequest.Login);

            if (user is null)
            {

                return null;
            }
            else
            {
                int attempts = 3;
                int duration = 60;

                if (!BCrypt.Net.BCrypt.EnhancedVerify(loginRequest.Password, user.PasswordHash))
                {
                    user.FailedAttempts++;
                    if (user.FailedAttempts >= attempts)
                        user.UnlockedDate = DateTime.UtcNow.AddSeconds(duration);
                    return null;
                }

                TokenResponce token = new  { RefreshToken }

                await _context.SaveChangesAsync();
                return user;
            }

        // DELETE: api/CinemaUsers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCinemaUser(int id)
        {
            var cinemaUser = await _context.CinemaUsers.FindAsync(id);
            if (cinemaUser == null)
            {
                return NotFound();
            }

            _context.CinemaUsers.Remove(cinemaUser);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CinemaUserExists(int id)
        {
            return _context.CinemaUsers.Any(e => e.UserId == id);
        }
    }
}
