﻿namespace LabWork16
{
    public class TokenResponce
    {
        public string Token { get; set; }
        public string? RefreshToken { get; set; }
    }
}
