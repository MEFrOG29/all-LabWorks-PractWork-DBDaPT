﻿using LabWork11.Services;
using System.Windows;



namespace LabWork11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Ispp3109Context _context = new();
        static MovieService _movieService = new(_context);

        public MainWindow()
        {
            InitializeComponent();
            MovieDataGrid.ItemsSource = _movieService.GetMovies();
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            await DeleteMoviesAsync();
        }

        public async Task DeleteMoviesAsync()
        {
            var movie = (Movie)MovieDataGrid.SelectedItem;
            try
            {
                await _movieService.RemoveMovieAsync(movie.MovieId);
                MovieDataGrid.ItemsSource = await _movieService.GetMoviesAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}