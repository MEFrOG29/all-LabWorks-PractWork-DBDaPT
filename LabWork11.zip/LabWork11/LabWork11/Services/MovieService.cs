﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace LabWork11.Services
{
    public class MovieService(Ispp3109Context context)
    {
        private readonly Ispp3109Context _context = context;

        public async Task<List<Movie>> GetMoviesAsync()
            => await _context.Movies.ToListAsync();

        public IEnumerable<Movie> GetMovies()
            => _context.Movies.ToList();

        public async Task RemoveMovieAsync(int id)
        {
            var movie = _context.Movies.Find(id);
            if(movie is not null)
            {
                context.Movies.Remove(movie);
                context.SaveChanges();
            }
        }
            

    }
}
