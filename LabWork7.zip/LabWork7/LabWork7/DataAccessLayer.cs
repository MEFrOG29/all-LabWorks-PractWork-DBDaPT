﻿using Microsoft.Data.SqlClient;

static class DataAccessLayer
{
    static private string _serverName = "mssql";
    static private string _database = "ispp3109";
    static private string _login = "ispp3109";
    static private string _password = "3109";

    public readonly static SqlConnectionStringBuilder Builder = new()
    {
        DataSource = _serverName,
        InitialCatalog = _database,
        UserID = _login,
        Password = _password
    };

    public static void ChangeDatabase(string server, string database, string login, string password)
    {
        Builder.DataSource = server;
        Builder.InitialCatalog = database;
        Builder.UserID = login;
        Builder.Password = password;
    }

    public static bool CheckConnection()
    {
        using SqlConnection connection = new(Builder.ConnectionString);
        try
        {
            connection.Open();
            return true;
        }
        catch
        {
            return false;
        }
    }

     
}


