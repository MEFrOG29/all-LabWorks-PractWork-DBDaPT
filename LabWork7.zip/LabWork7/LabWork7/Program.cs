﻿Console.WriteLine(DataAccessLayer.Builder);
DataAccessLayer.ChangeDatabase("mssql", "qwerty", "qwerty", "1111");
Console.WriteLine(DataAccessLayer.Builder);
Console.WriteLine(DataAccessLayer.CheckConnection());