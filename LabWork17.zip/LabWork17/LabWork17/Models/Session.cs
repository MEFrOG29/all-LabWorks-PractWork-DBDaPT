﻿using System.ComponentModel.DataAnnotations;

namespace LabWork17.Models;

public partial class Session
{
    public int SessionId { get; set; }

    [Display(Name = "Фильм")]
    public int MovieId { get; set; }

    [Display(Name = "Зал")]
    public byte HallId { get; set; }

    [Display(Name = "Цена")]
    public decimal Price { get; set; }

    [Display(Name = "Время начала сеанса")]
    public DateTime StartSessionDate { get; set; }

    [Display(Name = "3D")]
    public bool Is3D { get; set; }

    [Display(Name = "Зал")]
    public virtual Hall? Hall { get; set; } = null!;

    [Display(Name = "Фильм")]
    public virtual Movie? Movie { get; set; } = null!;

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}
