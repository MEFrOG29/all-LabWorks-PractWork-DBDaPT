﻿using System.ComponentModel.DataAnnotations;

namespace LabWork17.Models;

public partial class Hall
{
    public byte HallId { get; set; }

    public string Cinema { get; set; } = null!;

    public byte HallNumber { get; set; }

    public byte RowsCount { get; set; }

    public byte SeatsPerRow { get; set; }

    public bool IsVip { get; set; }

    [Display(Name = "Кинотеатр и зал")]
    public string? CinemaAndHall
    {
        get
        {
            return $"Кинотеатр: {Cinema},  номер зала: {HallNumber}";
        }
    }

    public virtual ICollection<Session> Sessions { get; set; } = new List<Session>();
}
