﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LabWork17.Contexts;
using LabWork17.Models;

namespace LabWork17.Pages.Tickets
{
    public class IndexModel : PageModel
    {
        private readonly LabWork17.Contexts.CinemaContext _context;

        public IndexModel(LabWork17.Contexts.CinemaContext context)
        {
            _context = context;
        }

        public IList<Ticket> Ticket { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Ticket = await _context.Tickets
                .Include(t => t.Session)
                .Include(t => t.Visitor).ToListAsync();
        }
    }
}
