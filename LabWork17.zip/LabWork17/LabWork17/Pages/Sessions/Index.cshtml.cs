﻿using LabWork17.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LabWork17.Pages.Sessions
{
    public class IndexModel : PageModel
    {
        private readonly LabWork17.Contexts.CinemaContext _context;

        [BindProperty(SupportsGet = true)]
        public string? FilmTitle { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SortColumn { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? Hall {  get; set; }

        public IndexModel(LabWork17.Contexts.CinemaContext context)
        {
            _context = context;
        }

        public IList<Session> Session { get; set; } = default!;

        public async Task OnGetAsync()
        {
            var halls = _context.Halls.Include(h => h.CinemaAndHall)
                .AsQueryable();

            ViewData["Halls"] = new SelectList(_context.Halls, "HallId", "CinemaAndHall");

            var sessions = _context.Sessions
                 .Include(s => s.Hall)
                 .Include(s => s.Movie)
                 .AsQueryable();

            if (!string.IsNullOrWhiteSpace(FilmTitle))
                sessions = sessions
                    .Where(s => s.Movie.Title.Contains(FilmTitle));

            if (SortColumn == "price")
                sessions = sessions
                    .OrderBy(s => s.Price);
            else if (SortColumn == "price_desc")
                sessions = sessions
                    .OrderByDescending(s => s.Price);

            Session = await sessions.ToListAsync();
        }
    }
}
