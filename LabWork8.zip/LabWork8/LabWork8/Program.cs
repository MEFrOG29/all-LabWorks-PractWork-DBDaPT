﻿using System.Data;

DatabaseContext database = new("mssql", "ispp3109", "ispp3109", "3109");
VisitorRepository visitor = new(database);
GenreRepository genre = new(database);

using IDbConnection connection = database.CreateConnection();
try
{
    connection.Open();
    Console.WriteLine("Соединение успешно");
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}