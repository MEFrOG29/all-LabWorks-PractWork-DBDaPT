﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieClassLibrary.Contexts;
using MovieClassLibrary.Models;

namespace LabWork13.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController(MovieDbContext context) : ControllerBase
    {
        private readonly MovieDbContext _context = context;

        // GET: api/Movies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Movie>>> GetMovies()
        {
            return await _context.Movies.ToListAsync();
        }

        [HttpGet("pages")]
        public async Task<ActionResult<IEnumerable<Movie>>> GetMoviesPagination(
            [FromQuery] string? sortBy = null,
            [FromQuery] int? page = null)
        {
            var movies = _context.Movies.AsQueryable();

            if (!string.IsNullOrWhiteSpace(sortBy))
            {
                movies = sortBy?.ToLower() switch
                {
                    "title" => movies.OrderBy(m => m.Title),
                    "publishedyeardescending" => movies.OrderByDescending(m => m.PublishedYear),
                    "publishedyear" => movies.OrderBy(m => m.PublishedYear),
                    _ => movies
                };
            }
            if (page.HasValue)
            {
                var pageSize = 3;
                movies = movies
                    .Skip(pageSize * ((int)page - 1))
                    .Take(pageSize);
            }

            return await movies.ToListAsync();
        }

        [HttpGet("filter")]
        public async Task<ActionResult<IEnumerable<Movie>>> GetFilteredMovies(
            [FromQuery] int? year = null,
            [FromQuery] string? title = null)
        {
            var movies = _context.Movies.AsQueryable();
            if (year.HasValue)
                movies.Where(m => m.PublishedYear == year);
            if (!string.IsNullOrWhiteSpace(title))
                movies.Where(m => m.Title.Contains(title));

            return await movies.ToListAsync();
        }


        // GET: api/Movies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Movie>> GetMovie(int id)
        {
            var movie = await _context.Movies.FindAsync(id);

            if (movie == null)
            {
                return NotFound();
            }

            return movie;
        }

        // PUT: api/Movies/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutMovie(int id, Movie movie)
        {
            if (id != movie.MovieId)
            {
                return BadRequest();
            }

            _context.Entry(movie).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MovieExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Movies
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Movie>> PostMovie(Movie movie)
        {
            _context.Movies.Add(movie);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetMovie", new { id = movie.MovieId }, movie);
        }

        // DELETE: api/Movies/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMovie(int id)
        {
            var movie = await _context.Movies.FindAsync(id);
            if (movie == null)
            {
                return NotFound();
            }

            _context.Movies.Remove(movie);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool MovieExists(int id)
        {
            return _context.Movies.Any(e => e.MovieId == id);
        }
    }
}
