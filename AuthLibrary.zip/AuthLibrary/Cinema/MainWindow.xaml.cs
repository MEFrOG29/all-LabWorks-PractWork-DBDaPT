﻿using AuthLibrary;
using AuthLibrary.Contexts;
using System.Windows;

namespace Cinema
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static CinemaUserContext _context = new();
        private static AuthService service = new(_context);
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                service.RegistrationAsync(LoginTextBox.Text, PasswordTextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Пользователь с таким логином уже зарегистрирован");
            }

        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            service.AuthenticationAsync(LoginTextBox.Text, PasswordTextBox.Text);
        }
    }
}