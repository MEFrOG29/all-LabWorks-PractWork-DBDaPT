﻿using AuthLibrary.Contexts;
using AuthLibrary.Models;
using Microsoft.EntityFrameworkCore;

namespace AuthLibrary
{
    public class AuthService(CinemaUserContext context)
    {
        private readonly CinemaUserContext _context = context;
        private string PasswordHash(string password)
            => BCrypt.Net.BCrypt.EnhancedHashPassword(password);

        public async Task<bool> RegistrationAsync(string login, string password)
        {
            if (_context.CinemaUsers.FirstOrDefault(u => u.Login == login) is not null)
                return false;
            var user = new CinemaUser()
            {
                Login = login,
                PasswordHash = PasswordHash(password),
                RoleId = 3
            };
            _context.CinemaUsers.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<CinemaUser> AuthenticationAsync(string login, string password)
        {
            var user = _context.CinemaUsers.FirstOrDefault(u => u.Login == login);

            if (user is null)
                return null;
            else
            {
                int attempts = 3;
                int duration = 60;

                if (!BCrypt.Net.BCrypt.EnhancedVerify(password, user.PasswordHash))
                {
                    user.FailedAttempts++;
                    if (user.FailedAttempts >= attempts)
                        user.UnlockedDate = DateTime.UtcNow.AddSeconds(duration);
                    return null;
                }

                await _context.SaveChangesAsync();
                return user;
            }
        }

        public async Task<string?> GetRoleByLoginAsync(string? login)
            => await _context.Database
                 .SqlQuery<string?>($@"select r.title
from cinemaUserRole as r
join cinemaUser as u on r.roleId = u.roleId
where u.login = {login}")
            .FirstOrDefaultAsync();

        public async Task<List<string?>> GetPrivilegiesByLoginAsync(string? login)
            => await _context.Database
                 .SqlQuery<string?>($@"select p.title
from cinemaPrivilege as p
join cinemaRolePrivilege as rp on p.privilegeId = rp.privilegeId
join cinemaUser as u on rp.roleId = u.roleId
where u.login = {login}")
            .ToListAsync();

        public async Task<List<string?>> GetPrivilegiesByRoleAsync(string? role)
            => await _context.Database
                 .SqlQuery<string?>($@"select p.title
from cinemaPrivilege as p
join cinemaRolePrivilege as rp on p.privilegeId = rp.privilegeId
join cinemaUserRole as r on rp.roleId = r.roleId
where r.title = {role}")
            .ToListAsync();
    }
}
