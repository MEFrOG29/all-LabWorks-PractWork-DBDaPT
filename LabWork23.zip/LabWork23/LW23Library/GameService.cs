﻿using LW23Library.Contexts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LW23Library
{
    public class GameService(GameContext context)
    {
        private readonly GameContext _context = context;

        public async Task SaveLogoFileAsync(string? title, string? logo)
            => await _context.Database
            .ExecuteSqlAsync($@"update LW23Games
set logoInfo = {logo}
where name = {title}");        
    }
}
