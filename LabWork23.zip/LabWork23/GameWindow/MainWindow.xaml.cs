﻿using LW23Library;
using LW23Library.Contexts;
using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GameWindow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static GameContext _context = new();
        private static GameService service = new(_context);

        public MainWindow()
        {
            InitializeComponent();
        }








 private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if(LogoTextBox.Text is null)
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (TitleTextBox.Text is null)
            {
                MessageBox.Show("Игра не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            service.SaveLogoFileAsync(TitleTextBox.Text, LogoTextBox.Text);
            OpenFileDialog openFileDialog = new();
            File.Copy(LogoTextBox.Text, $@"{Environment.CurrentDirectory}\GamesLogo", true);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new();
            openFileDialog.Filter = "Image Files|*.bmp;*/jpg;*.jpeg;*.png;*.gif";
            if()
        }
    }
}