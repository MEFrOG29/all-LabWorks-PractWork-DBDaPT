﻿using CinemaDbLibrary.Contexts;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaDbLibrary
{
    public class CinemaService(CinemaContext context)
    {
        private readonly CinemaContext _context = context;

        public async List<T> SaveSessionInfo(DateTime startDate, string cinema)
        {
            var fileName = "info.csv";

            var rows = _context.Sessions.Include(h => h.Hall).Include(m => m.Movie.Title).Include(s => s.StartSessionDate).Include(p => p.Price);
            var movies = rows.Where(m => m.Hall.Cinema == cinema && m.StartSessionDate == startDate);
            List<SessionInfoDto> sessions = new();
            foreach (var movie in movies)
            {
                SessionInfoDto session = new()
                {
                    Title = movie.Movie.Title,
                    StartSession = movie.StartSessionDate,
                    Price = movie.Price,
                    Cinema = movie.Hall.Cinema
                };
            }
        }
            
    }
}