﻿using System;
using System.Collections.Generic;

namespace CinemaDbLibrary.Models;

public partial class Movie
{
    public int MovieId { get; set; }

    public string Title { get; set; } = null!;

    public short Duration { get; set; }

    public short PublishedYear { get; set; }

    public string? Description { get; set; }

    public byte[]? Poster { get; set; }

    public string? AgeRating { get; set; }

    public DateOnly? MovieRelease { get; set; }

    public DateOnly? MovieEnd { get; set; }

    public bool? IsDeleted { get; set; }

    public virtual ICollection<Session> Sessions { get; set; } = new List<Session>();

    public virtual ICollection<Genre> Genres { get; set; } = new List<Genre>();
}
