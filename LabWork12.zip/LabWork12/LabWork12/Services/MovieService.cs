﻿
using LabWork12.Contexts;
using LabWork12.Models;
using Microsoft.EntityFrameworkCore;

namespace LabWork12.Services
{
    public class MovieService(CinemaDbContext context)
    {
        private CinemaDbContext _context = context;

        public async Task<List<Movie>> GetUserSortedMovieAsync(string sort)
            => await _context.Movies
            .FromSqlRaw($"select * from movie order by {sort}")
            .ToListAsync();

        public async Task<List<Movie>> GetByNameAndPublishedYearAsyns(string title, int publishedYear)
            => await _context.Movies
            .FromSql($"select * from movie where title = {title} and publishedyear >={publishedYear}")
            .ToListAsync();

        public async Task<List<string>> GetMoviesGenresByIdAsync(int id)
            => await _context.Database
                .SqlQuery<string>($@"select g.name 
from genre as g 
join movieGenre as mg on g.genreId = mg.genreId 
where mg.movieId = {id}")
                .ToListAsync();
    }
}
