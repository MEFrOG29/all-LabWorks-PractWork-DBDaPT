﻿using LabWork12.Contexts;
using LabWork12.Models;
using Microsoft.EntityFrameworkCore;

namespace LabWork12.Services
{
    public class TicketService(CinemaDbContext context)
    {
        private CinemaDbContext _context = context;

        public async Task<DateTime> GetDateTimeSessionByTicketIdAsync(int id)
            => await _context.Database
            .SqlQuery<DateTime>($@"select s.dateTime as value
from session as s 
join ticket as t on t.sessionId = s.sessionId 
where t.ticketId = {id}")
            .FirstOrDefaultAsync();
       
    }
}
