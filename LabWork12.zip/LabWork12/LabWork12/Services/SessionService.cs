﻿using LabWork12.Contexts;
using Microsoft.EntityFrameworkCore;

namespace LabWork12.Services
{
    public class SessionService(CinemaDbContext context)
    {
        private CinemaDbContext _context = context;

        public async Task<int> IncreasePriceByHallIdAsync(int value, int hallId)
            => await _context.Database
            .ExecuteSqlAsync($"update session set price += {value} where hallId = {hallId}");
    }
}
