﻿using LabWork12.Contexts;
using LabWork12.Models;
using LabWork12.Services;

using CinemaDbContext context = new();

MovieService movieService = new(context);
SessionService sessionService = new(context);
TicketService ticketService = new(context);

string sort = "duration";
var movies = await movieService.GetUserSortedMovieAsync(sort);
movies.ForEach(movie => Console.WriteLine($"{movie.Title}"));

Console.WriteLine();

movies = await movieService.GetByNameAndPublishedYearAsyns("Тачки", 2009);
movies.ForEach(movie => Console.WriteLine($"{movie.MovieId} {movie.Title} , {movie.PublishedYear}"));

var result = await sessionService.IncreasePriceByHallIdAsync(50, 2);
Console.WriteLine(result);

var movieGenres = await movieService.GetMoviesGenresByIdAsync(3);
movieGenres.ForEach(Console.WriteLine);

var sessionDateTime = await ticketService.GetDateTimeSessionByTicketIdAsync(6);
Console.WriteLine(sessionDateTime);