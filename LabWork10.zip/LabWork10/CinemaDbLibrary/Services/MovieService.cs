﻿using CinemaDbLibrary.Models;
using LabWork10.Context;
using Microsoft.EntityFrameworkCore;

namespace CinemaDbLibrary.Services
{
    public class MovieService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Movie>> GetMoviesAsync()
            => await _context.Movies.ToListAsync();
    }
}
