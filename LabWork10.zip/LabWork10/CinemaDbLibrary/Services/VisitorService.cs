﻿using LabWork10.Context;
using LabWork10.Models;
using Microsoft.EntityFrameworkCore;

namespace CinemaDbLibrary.Services
{
    public class VisitorService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Visitor>> GetVisitorsAsync()
            => await _context.Visitors.ToListAsync();
    }
}
