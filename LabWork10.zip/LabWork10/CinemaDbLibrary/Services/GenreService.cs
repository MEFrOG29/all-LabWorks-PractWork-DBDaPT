﻿using LabWork10.Context;
using CinemaDbLibrary.Models;
using Microsoft.EntityFrameworkCore;

namespace CinemaDbLibrary.Services
{
    public class GenreService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Genre>> GetGenresAsync()
            => await _context.Genres.ToListAsync();
    }
}
