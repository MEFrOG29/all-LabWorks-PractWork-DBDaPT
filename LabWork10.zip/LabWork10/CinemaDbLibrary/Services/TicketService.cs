﻿using LabWork10.Models;
using LabWork10.Context;
using Microsoft.EntityFrameworkCore;

namespace CinemaDbLibrary.Services
{
    public class TicketService(AppDbContext context)
    {
        private readonly AppDbContext _context = context;

        public async Task<List<Ticket>> GetTicketsAsync()
            => await _context.Tickets.ToListAsync();
    }
}
