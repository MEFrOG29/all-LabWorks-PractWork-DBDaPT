﻿using LabWork10.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace CinemaDbLibrary.Models
{
    [Table("Movie")]
    public class Movie
    {
        public int MovieId { get; set; }
        public string Title { get; set; } = null!;
        public short Duration { get; set; }
        public short PublishedYear { get; set; }
        public string? Description { get; set; }
        public byte[]? Poster { get; set; }
        public string? AgeRating { get; set; }
        public DateTime? MovieRelease { get; set; }
        public DateTime? MovieEnd { get; set; }
        public bool? IsDeleted { get; set; }

        public IEnumerable<Genre>? Genres { get; set; } 
    }
}
