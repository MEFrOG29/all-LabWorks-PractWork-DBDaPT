﻿using LabWork10.Context;
using CinemaDbLibrary.Services;

using var context = new AppDbContext();

var visitorService = new VisitorService(context);
var visitors = await visitorService.GetVisitorsAsync();
foreach (var visitor in visitors)
    Console.WriteLine($"{visitor.VisitorId}, {visitor.Phone}," +
        $" {visitor.Name}, {visitor.Birthday}, {visitor.Email}");

var ticketService = new TicketService(context);
var tickets = await ticketService.GetTicketsAsync();
foreach (var ticket in tickets)
    Console.WriteLine($"{ticket.TicketId}, {ticket.SessionId}," +
        $" {ticket.VisitorId}, {ticket.Row}, {ticket.Seat}");

var genreService = new GenreService(context);
var genres = await genreService.GetGenresAsync();
foreach (var genre in genres)
    Console.WriteLine($"{genre.GenreId}, {genre.Name}");

var movieService = new MovieService(context);
var movies = await movieService.GetMoviesAsync();
foreach (var movie in movies)
    Console.WriteLine($"{movie.MovieId}, {movie.Title}," +
        $" {movie.Duration}, {movie.PublishedYear}, {movie.Description}," +
        $" {movie.Poster}, {movie.AgeRating}, {movie.MovieRelease}, {movie.MovieEnd}, {movie.IsDeleted}");

